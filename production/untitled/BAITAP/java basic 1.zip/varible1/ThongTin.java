package BAITAP.varible1;

public class ThongTin {
    // gọi lai hàm
    public static String truong = "DHQN";
    public static String khoa = "CNTT";
// in thông tin
    public void inThongtin(){

        System.out.println("TênSV:");
    }
}
