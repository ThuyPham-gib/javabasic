package BAITAP.varible1;

//local variable
public class SinhVien {
    public void sinhvien(String ten){
        int id;
        //String SV;
        //SV = "NGuyễn Văn A";
        //System.out.println(SV);


        this.ten = ten;
        soSV++;

        id = soSV;
        System.out.println("ID SV la:" +id);

        //String address = "Binh Dinh";
       //System.out.println("Dia chi sinh vien:" +address);

    }
    // instance variable
    public String ten;

    // static variable
    public static int soSV = 0;

    public void inThongtin(){
        System.out.println("Tên SV:" + ten);
        System.out.println("SL SV:" + soSV);
        System.out.println("Truong:" + ThongTin.truong);
        System.out.println("Khoa:" + ThongTin.khoa);
    }


// Hàm main
    public static void main(String[] args){
        SinhVien SV = new SinhVien();
        //SV.sinhvien();
        SV.inThongtin();
    }
}
